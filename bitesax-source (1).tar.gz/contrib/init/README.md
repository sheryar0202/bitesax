Sample configuration files for:
```
SystemD: bitesaxd.service
Upstart: bitesaxd.conf
OpenRC:  bitesaxd.openrc
         bitesaxd.openrcconf
CentOS:  bitesaxd.init
macOS:    org.bitesax.bitesaxd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
